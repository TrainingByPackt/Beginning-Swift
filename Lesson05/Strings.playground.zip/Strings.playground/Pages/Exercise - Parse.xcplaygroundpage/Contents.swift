
let info = """
	title: Beginning Swift
	type: course
	year: 2018
	publisher: Packt Publishing
	topic: programming
	"""

var result = [String: String]()

// your code goes here

print(result)
// output should be something like
// ["year": "2018", "publisher": "Packt Publishing", "title": "Beginning Swift", "topic": "programming", "type": "course"]
