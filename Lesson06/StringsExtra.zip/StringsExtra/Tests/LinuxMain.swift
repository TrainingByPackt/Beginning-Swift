import XCTest
@testable import StringsExtraTests

XCTMain([
    testCase(StringsExtraTests.allTests),
])
