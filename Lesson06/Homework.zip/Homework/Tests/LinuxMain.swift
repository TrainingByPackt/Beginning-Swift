import XCTest
@testable import HomeworkTests

XCTMain([
    testCase(HomeworkTests.allTests),
])
