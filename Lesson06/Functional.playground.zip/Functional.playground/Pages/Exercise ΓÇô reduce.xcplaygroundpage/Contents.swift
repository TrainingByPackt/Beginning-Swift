
let numbers = [0,2,4,2,4,8]

var sum = 0
for nr in numbers {
	sum += nr
}
let average = Double(sum) / Double(numbers.count)

