//: HelloWorld.playground

import UIKit

let message = "Hello, world."
print(message)

