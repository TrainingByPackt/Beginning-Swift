//: Playground - noun: a place where people can play

import UIKit

var helloWorld = "Hello, World"
var 你好世界 = "Hello World"
var 🙂 = "Smile!"

print(你好世界)
print(🙂)
print(Float.pi)
print(Double.pi)


var anyType : Any
anyType = "Hello, world"
anyType = 3.14159


var country = (dialCode: 44, isoCode: "GB", name: "Great Britain")
print(country.0)
print(country.1)
print(country.2)
print(country.name)


let vv : String?



